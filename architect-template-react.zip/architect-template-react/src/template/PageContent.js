import AboutSection from "./AboutSection"
import ContactSection from "./ContactSection"
import LocationMap from "./LocationMap"
import ProjectSection from "./ProjectSection"



function PageContent() {
    return (
    <>
        <div className="w3-content w3-padding" style={{ maxWidth: 1564 }}>
            <ProjectSection></ProjectSection>
            <AboutSection></AboutSection>
            <ContactSection></ContactSection>
            <LocationMap></LocationMap>
        </div>
    </>
    )
}

export default PageContent